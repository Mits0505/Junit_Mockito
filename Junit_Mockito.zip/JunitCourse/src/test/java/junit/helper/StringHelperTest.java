package junit.helper;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class StringHelperTest {
	
	StringHelper stringHelper;
	
	@BeforeClass
	public static void setup(){
	   System.out.println("Before Class");
	}
	
	@Before
	public void beforeTest(){
	   stringHelper = new StringHelper(); 
       System.out.println("Before Test");
	}

	@Test
	public void testTruncateAInFirst2Positions_AInFirstTwoPositions() {
	 
	 System.out.println("Test1 Execution");
		
	 String actual = stringHelper.truncateAInFirst2Positions("AACD");
	 String expected = "CD";
	 
	 assertEquals(expected, actual); 
	}
	
	@Test
	public void testTruncateAInFirst2Positions_AInFirstPosition(){
		
		 System.out.println("Test2 Execution");
		 
		 StringHelper stringHelper = new StringHelper();
		 
		 assertEquals("CD",stringHelper.truncateAInFirst2Positions("ACD"));
	}

	@Test
	public void testAreFirstAndLastTwoCharactersTheSame_BasicNegativeScenario(){
		
		 System.out.println("Test3 Execution");
		 
		 StringHelper stringHelper = new StringHelper();

		 assertFalse(stringHelper.areFirstAndLastTwoCharactersTheSame("ABCD"));
	}
	
	@Test
	public void testAreFirstAndLastTwoCharactersTheSame_BasicPositiveScenario(){
		
		 System.out.println("Test4 Execution");
		 
		 StringHelper stringHelper = new StringHelper();

		 assertTrue(stringHelper.areFirstAndLastTwoCharactersTheSame("ABAB"));
	}
	
	@After
	public void teardown(){
       System.out.println("After Test");
	}
	
	@AfterClass
	public static void afterClass(){
	   System.out.println("After Class");
	}
}
